To run the following code in linux, use the following commands:

gcc -fopenmp helloworld.c
./a.out

export OMP_NUM_THREADS = 3
./a.out





#include <stdio.h>
#include <omp.h>

int main()
{
   #pragma omp parallel
   {
      int ID = omp_get_thread_num();
      printf("hello (%d)", ID);
      printf(" world (%d) \n", ID);
   }
}
